#Rust Raid Decider
#Array
user_info = []

def raid_decider():
    print("Welcome to the Rust raid decider! This program will help you decide if you should raid a base or not. First, get your decision on if you should raid or not, then find out the boom you will need.")

def gear():
    your_gear = input("What level gear do you have?")
    their_gear = input("What level gear do they have?")

def base():
    base = int(input("How many squares away is their base from yours?"))
    doors = int(input("Approximately how many doors do you think you will need to boom?"))

def wipe():
    wipe = int(input("How many days are you away from wipe day?"))

def boom():
    kind_boom = int(input("What kind of boom will you use? (Satchel, C4, Rockets)"))
    much_boom = int(input("How much boom do you have?"))

##def your_data():
##    #display user data in a dictionary and ask if it is all correct
##
##def decision():
    #use if else statements to decide if raid or no


#raid or not will use gear, base distance, and wipe to determine if you should
#Necessary boom will use base doors, kind of boom, and how much boom to calculate how much more boom you need
def menu():
    print("---------") #underline
     print ("Main Menu") #header
    print("---------") #underline
    print("1. To Raid or Not to Raid") #choice 1
    print("2. Neccessary Boom") #choice 2
    print("3. Exit") #exit
    choice = int(input("Enter your choice:")) #prompt user for input
    return choice #return value

def main():
    raid_decider()
    menu()

main()
