#Rust Raid Decider
def raid_decider(): #introduction message
    print("Welcome to the Rust raid decider! This program will help you decide if you should raid a base or not. First, get your decision on if you should raid or not, then find out the boom you will need.")

def gear(): #get your gear level
    print("Choose your gear level:")
    print("1: Wood Armor")
    print("2: Roadsign Armor")
    print("3: Facemask and Metal Chest Plate")
    
    #error handle with loop
    while True:
        try:
            your_gear = int(input("Enter the number corresponding to your gear level: "))
            if your_gear in [1, 2, 3]: #if valid choice break loop
                break
            else:
                print("Invalid choice. Please select 1, 2, or 3.") #wrong number
        except ValueError:
            print("Invalid input. Please enter a number.") #if they enter a letter

    #get opponents gear level
    print("Choose their gear level:")
    print("1: Wood Armor")
    print("2: Roadsign Armor")
    print("3: Facemask and Metal Chest Plate")
    
    #error handle with loop again
    while True:
        try:
            their_gear = int(input("Enter the number corresponding to their gear level: "))
            if their_gear in [1, 2, 3]: #if valid choice break loop
                break
            else:
                print("Invalid choice. Please select 1, 2, or 3.") #wrong number
        except ValueError:
            print("Invalid input. Please enter a number.") #if they enter a letter
    return your_gear, their_gear #return answers

def base(): #get base distance
    while True: #loop
        try:
            base_dist = int(input("How many squares away is their base from yours?")) #how far is their base from yours
            if base_dist < 0: #cannot have negative doors
                print("Their base cannot be negative squares away, please enter a positive number.")
                continue
            return base_dist #return answer
        except ValueError:
             print("Invalid input. Please enter a number.") #error handle wooo!!!
    
def doors(): #get doors number and type
    while True: #loop
        try:
            num_doors = int(input("Approximately how many doors do you think you will need to boom? "))  #how many doors they got
            if num_doors < 0: #cannot have negative doors
                print("They cannot have negative doors, please enter a positive number.")
                continue
            break  #exit loop if valid
        except ValueError:
            print("Invalid input. Please enter a number.")  #error for entering a string
    print("Choose what kind of doors they have:")  #door type list
    print("1: Wooden Doors")
    print("2: Sheet Metal Doors")
    print("3: Garage Doors")
    print("4: Armored Doors")    
    while True: #error handle door type
        try:
            door_type = int(input("Enter the number corresponding to what doors they have: ")) #get door type
            if door_type in [1, 2, 3, 4]:  #if valid door type break
                break
            else:
                print("Invalid choice. Please select 1, 2, 3, or 4.")  #invalid number
        except ValueError:
            print("Invalid input. Please enter a number.")  #if they eneter a string
    return num_doors, door_type  #return answers

def boom(): #get what kind of boom you will use
    print("Choose what kind of boom you will be using:")
    print("1: Satchel Charge")
    print("2: Rockets")
    print("3: C4")
    
    #more error handling again yay!
    while True:
        try:
            boom_type = int(input("Enter the number corresponding to what boom you will use:"))
            if boom_type in [1, 2, 3]: #if valid choice break loop
                break
            else:
                print("Invalid choice. Please select 1, 2, or 3.") #wrong number
        except ValueError:
            print("Invalid input. Please enter a number.") #if they enter a letter
    return boom_type #return answer

#decide if raid or not
def decision(your_gear, their_gear, base_dist):
    #determine if high risk or minimal risk distance from base
    if base_dist >= 10: #10 or more squares away is high risk
        risk_level = "high"
    else:
        risk_level = "minimal" #less than 10 squares is minimal risk
        
    gear_difference = your_gear - their_gear #how different is their gearr from yours

    if gear_difference == 2:
        if risk_level == "high": #you have way better gear but far away
            print("You have a significant gear advantage over the opponent and the risk is high, raid them but be careful running to and from their base.")
        else: #oyu have way better gear but are close
            print("You have a significant gear advantage over the opponent and the risk is minimal, raid them.")
    elif gear_difference == 1:
        if risk_level == "high": #you have slightly better gear and are far
            print("You have a slight gear advantage over the opponent and the risk is high, raid them but be careful running to and from their base.")
        else: #you ahve slightly better gear and are close
            print("You have a slight gear advantage over the opponent and the risk is minimal, raid them.")
    elif gear_difference == 0:
        if risk_level == "high": #same gear and far
            print("You are evenly matched with the opponent and the risk is high, don't raid them.")
        else: #same gear and close
            print("You are evenly matched with the opponent and the risk is minimal, raid them.")
    elif gear_difference == -1:
        if risk_level == "high": #they have slightly better gar and are far
            print("You have a slight gear disadvantage compared to the opponent and the risk is high, don't raid them.")
        else: #they have slightly better gear but are close
            print("You have a slight gear disadvantage compared to the opponent and the risk is minimal, raid them.")
    elif gear_difference == -2:
        if risk_level == "high": #they have way better gear and are far
            print("You are at a significant gear disadvantage compared to the opponent and the risk is high, don't raid them.")
        else: #they have way better gear and are close
            print("You are at a significant gear disadvantage compared to the opponent and the risk is minimal, don't raid them.")

#find the necessary amount of boom for your raid
def necessary_boom(boom_type, num_doors, door_type):
    #create dictionary to store boom data once you parse the file
    boom_data = {1: {}, 2: {}, 3: {}}
    with open('boom_doors.txt', 'r') as file: #open and read file and parse data
        for line in file: #for each line in txt file
            line = line.strip().lower() #strip spaces and such and put in lowercase           
            #separate by type of boom in file and assign a number to each to function as a key
            if "satchel" in line:
                boom_type_key = 1
            elif "rockets" in line:
                boom_type_key = 2
            elif "c4" in line:
                boom_type_key = 3
            else:
                continue  #if boom type is not in list (which they all are) it will skip it
            
            try:
                type_amount = line.split('-')[1].strip()  #get door type and boom amount data after the boom type
                door_info = type_amount.split(', ') #split door types with boom amount
                for door in door_info: #for each door in each line
                    door_type_string, boom_required = door.split(':') #split door type and required boom and assign them to variables
                    #key for door type by number and strip sapces/ check if valid door type return none if key doesnt exist
                    door_type_key = {"wooden": 1, "sheetmetal": 2, "garagedoor": 3, "armored": 4}.get(door_type_string.strip().lower(), None)
                    #if valid door, update data boom_data
                    if door_type_key: 
                        boom_data[boom_type_key][door_type_key] = int(boom_required.strip())
            #error handling yippee!!!
            except IndexError: #if line in file is not formatted correctly (which they all are correct anyways)
                print(f"Skipping line: {line}") #skip the line and proceed
                continue
    #final step
    if boom_type in boom_data and door_type in boom_data[boom_type]: #if all required info is there, find the amount of boom needed
        required_boom = boom_data[boom_type][door_type] * num_doors #using boom type and door type multiply by number of doors
        boom_type_string = {1: 'Satchel Charge', 2: 'Rocket', 3: 'C4'} #dictionary for boom type
        door_type_string = {1: "Wooden Door", 2: "Sheet Metal Door", 3: "Garage Door", 4: "Armored Door"} #dictionary for door type
        print(f"You will need {required_boom} {boom_type_string[boom_type]}(s) to break {num_doors} {door_type_string[door_type]}s.") #combine all info given to show how much boom you will need yay all done :)
    else:
        print("Invalid door type or boom type.") #error

#main menu
def menu():
    print("---------") #overline
    print ("Main Menu") #header
    print("---------") #underline
    print("1. To Raid or Not to Raid") #choice 1
    print("2. Neccessary Boom") #choice 2
    print("3. Exit") #choice 3 exit
    while True: #loop
        try: #error handle
            choice = int(input("Enter your choice: "))  #get input
            if choice in [1, 2, 3]:  #if valid choice
                return choice  #return choice
            else:
                print("Invalid choice. Please enter 1, 2, or 3.") #entered wrong number
        except ValueError:
            print("Invalid input. Please enter a number.")  #entered a string

def process_menu_choice(choice): #process choice
    if choice == 1: #if user chose 1, run gear analysis, distance, and decision
        your_gear, their_gear = gear()
        base_dist = base()
        decision(your_gear, their_gear, base_dist)
    elif choice == 2: #if user chose 2, run door type, number of doors, boom type, and necessary boom to calculate what you need
        door_type, num_doors = doors()
        boom_type = boom()
        necessary_boom(boom_type, door_type, num_doors)
    elif choice == 3: #if user chose 3, exit program
        print("Exiting the program. Good Luck, and don't get hit with an Eoka!") #ifykyk
        return False  #exit the loop
    else: #if user presses anything besides 1-3, make them do it again
        print("Invalid choice. Please try again.")
    return True  #continue the loop

def main():
    raid_decider() #show introduction only when starting program
    while True:  #loop menu
        choice = menu() #display menu
        if not process_menu_choice(choice): #exit if choice is 3
            break

main()
